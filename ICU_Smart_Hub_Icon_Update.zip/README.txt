ICU Smart Hub - App Icon Update

1. Upload icon-192.png, icon-512.png, apple-touch-icon.png and manifest.json to the ROOT of your GitHub repository (next to index.html).
2. Edit index.html and add these lines inside <head>:
<link rel="manifest" href="./manifest.json">
<link rel="apple-touch-icon" sizes="180x180" href="./apple-touch-icon.png">
<link rel="icon" type="image/png" sizes="192x192" href="./icon-192.png">
<meta name="theme-color" content="#073b68">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-title" content="ICU Smart Hub">
3. Commit changes, wait for GitHub Pages deployment, remove old home screen shortcuts and re-add from Safari if iPhone icon is cached.

Note: Existing published files remain public. Ensure institutional authorization before publishing internal clinical policies.
